﻿beforeEach(angular.mock.module("AdventureWorksAngularApp", function ($provide) {
    $provide.constant("FakeAllProductsData", [
            { "ProductID": 1, "Name": "Adjustable Race", "Color": null, "ListPrice": 82.9873 },
            { "ProductID": 2, "Name": "Bearing Ball", "Color": null, "ListPrice": 12.3169 },
            { "ProductID": 3, "Name": "BB Ball Bearing", "Color": null, "ListPrice": 67.2170 },
            { "ProductID": 4, "Name": "Headset Ball Bearings", "Color": null, "ListPrice": 78.3150 },
            { "ProductID": 5, "Name": "Blade", "Color": null, "ListPrice": 72.0915 },
            { "ProductID": 6, "Name": "LL Crankarm", "Color": "Black", "ListPrice": 78.7362 },
            { "ProductID": 7, "Name": "ML Crankarm", "Color": "Black", "ListPrice": 85.7822 },
            { "ProductID": 8, "Name": "HL Crankarm", "Color": "Black", "ListPrice": 44.9268 },
            { "ProductID": 9, "Name": "Chainring Bolts", "Color": "Silver", "ListPrice": 9.3536 },
            { "ProductID": 10, "Name": "Chainring Nut", "Color": "Silver", "ListPrice": 50.5313 },
            { "ProductID": 11, "Name": "Chainring", "Color": "Black", "ListPrice": 59.2719 },
            { "ProductID": 12, "Name": "Crown Race", "Color": null, "ListPrice": 42.5201 },
            { "ProductID": 13, "Name": "Chain Stays", "Color": null, "ListPrice": 37.7018 },
            { "ProductID": 14, "Name": "Decal 1", "Color": null, "ListPrice": 77.1635 },
            { "ProductID": 15, "Name": "Decal 2", "Color": null, "ListPrice": 99.4469 },
            { "ProductID": 16, "Name": "Down Tube", "Color": null, "ListPrice": 73.8454 },
            { "ProductID": 17, "Name": "Mountain End Caps", "Color": null, "ListPrice": 35.0958 },
            { "ProductID": 18, "Name": "Road End Caps", "Color": null, "ListPrice": 69.7113 },
            { "ProductID": 19, "Name": "Touring End Caps", "Color": null, "ListPrice": 55.5698 },
            { "ProductID": 20, "Name": "Fork End", "Color": null, "ListPrice": 17.3703 }
    ]);

    $provide.constant("FakeProductsData", [
            { "ProductID": 1, "Name": "Adjustable Race", "Color": null, "ListPrice": 82.9873 },
            { "ProductID": 2, "Name": "Bearing Ball", "Color": null, "ListPrice": 12.3169 },
            { "ProductID": 3, "Name": "BB Ball Bearing", "Color": null, "ListPrice": 67.2170 }
    ]);

    $provide.constant("FakeProductData", 
        { "ProductID": 3, "Name": "BB Ball Bearing", "Color": null, "ListPrice": 67.2170 }
    );
}));