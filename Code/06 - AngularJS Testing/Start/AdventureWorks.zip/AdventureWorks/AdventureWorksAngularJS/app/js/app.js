angular.module("AdventureWorksAngularApp", [
  "AdventureWorksAngularApp.services",
  "AdventureWorksAngularApp.controllers",
  "AdventureWorksAngularApp.filters",
  "AdventureWorksAngularApp.directives",
  "ngRoute"
]).
config(["$routeProvider", function($routeProvider) {
  $routeProvider.
	when("/products", { templateUrl: "partials/products.html", controller: "ProductsController" }).
	when("/products/:id", { templateUrl: "partials/product.html", controller: "ProductController" }).
	otherwise({ redirectTo: "/products" });
}]);