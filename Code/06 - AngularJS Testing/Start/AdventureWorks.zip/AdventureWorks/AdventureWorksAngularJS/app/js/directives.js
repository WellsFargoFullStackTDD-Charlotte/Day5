angular.module("AdventureWorksAngularApp.directives", []).
    directive("productlink", function () {
        var directive = {};
        directive.restrict = "E", 
        directive.template = "<a href='#/products/{{product.ProductID}}'>{{product.Name}}</a>";
        return directive;
    });
