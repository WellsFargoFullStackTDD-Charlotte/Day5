angular.module("AdventureWorksAngularApp.services", []).
    constant("AdventureWorksServiceURL", {
        "url": "http://localhost:4287/api/products/",
    }).
    factory("AdventureWorksService", function ($http, AdventureWorksServiceURL) {

        var adventureWorksService = {};

        adventureWorksService.getProducts = function () {
            return $http({
                method: "GET",
                url: AdventureWorksServiceURL.url
            });
        }

        adventureWorksService.getProductDetails = function (id) {
            return $http.get(AdventureWorksServiceURL.url + id);
        }

        return adventureWorksService;
    });