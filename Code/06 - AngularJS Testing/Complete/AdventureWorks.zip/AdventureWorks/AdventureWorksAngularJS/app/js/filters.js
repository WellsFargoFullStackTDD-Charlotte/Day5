angular.module("AdventureWorksAngularApp.filters", []).
    filter("SearchFilter", function () {
        return function (products, nameFilter) {
            if (nameFilter === null) return products;

            var filtered = [];
            var match = new RegExp(nameFilter, "i");
            for (var i = 0; i < products.length; i++) {
                if (match.test(products[i].Name)) { filtered.push(products[i]); }
            }
            return filtered;
        };
    });
