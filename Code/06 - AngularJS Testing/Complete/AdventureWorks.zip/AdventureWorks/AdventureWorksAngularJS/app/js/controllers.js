angular.module("AdventureWorksAngularApp.controllers", []).

  /* Drivers controller */
  controller("ProductsController", function ($scope, AdventureWorksService) {
    $scope.nameFilter = null;
    $scope.products = [];

    AdventureWorksService.getProducts().success(function (response) {
        $scope.products = response;
    });
  }).

  /* Driver controller */
  controller("ProductController", function ($scope, $routeParams, AdventureWorksService) {
    $scope.id = $routeParams.id;
    $scope.races = [];
    $scope.product = null;

    AdventureWorksService.getProductDetails($scope.id).success(function (response) {
        $scope.product = response; 
    });
  });