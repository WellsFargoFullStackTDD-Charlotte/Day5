describe('AdventureWorksAngularApp', function () {

    browser.get('index.html');

    it('should automatically redirect to /products when location hash/fragment is empty', function() {
        expect(browser.getLocationAbsUrl()).toMatch("/products");
    });

    it('should have a title', function () {
        expect(browser.getTitle()).toEqual('Adventure Works');
    });

    it('should do a search', function () {
        element(by.model('nameFilter')).sendKeys('LL');

        var products = element.all(by.repeater('product in products'));
        expect(products.count()).toEqual(4);
        expect(products.get(3).getText()).toEqual('6 LL Crankarm Black $78.74');
    });
});
