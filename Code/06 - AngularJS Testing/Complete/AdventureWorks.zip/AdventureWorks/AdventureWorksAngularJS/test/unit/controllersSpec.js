describe("Controller: ProductsController", function () {

    // ** Arrange **
    beforeEach(module("AdventureWorksAngularApp"));

    var scope, service;
    beforeEach(inject(function ($httpBackend, $rootScope, $controller,
        AdventureWorksService, AdventureWorksServiceURL, FakeProductsData) {

        // Fake Product Data
        $httpBackend.expectGET(AdventureWorksServiceURL.url).respond(FakeProductsData);
        
        // Create a Mock Scope
        scope = $rootScope.$new();
        service = AdventureWorksService;
        spyOn(service, 'getProducts').andCallThrough();

        // ** Act **
        // Create controller and pass fake scope
        $controller("ProductsController", { $scope: scope });

        // Then we flush the httpBackend to resolve the fake http call
        $httpBackend.flush();
    }));

    // ** Assert **
    // Test that controller returns 3 products
    it("should return a list with three products", function () {
        expect(scope.products.length).toBe(3);
    });

    // Check product names match fake data
    it("should retrieve the names of the products", function () {
        expect(scope.products[0].Name).toBe("Adjustable Race");
        expect(scope.products[1].Name).toBe("Bearing Ball");
        expect(scope.products[2].Name).toBe("BB Ball Bearing");
    });

    it("should call AdventureWorksService.getProducts()", function () {
        expect(service.getProducts).toHaveBeenCalled();
    });
});