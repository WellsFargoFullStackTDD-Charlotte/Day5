describe("Filter: SearchFilter", function () {

    // ** Arrange **
    beforeEach(module("AdventureWorksAngularApp"));

    var data, searchFilter;
    beforeEach(inject(function ($filter, FakeProductsData) {
        searchFilter = $filter("SearchFilter");
        data = FakeProductsData;
    }));

    // ** Act & Assert **
    it("returns correct count when given null", function () {
        expect(searchFilter(data, null).length).toEqual(3);
    });

    it("returns the correct value when given a string of chars", function () {
        expect(searchFilter(data, 'Q').length).toEqual(0);
    });
}); 