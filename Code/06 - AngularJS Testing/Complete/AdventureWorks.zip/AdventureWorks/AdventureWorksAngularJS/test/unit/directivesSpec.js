describe("Directive: productlink", function () {

    // ** Arrange **
    beforeEach(module("AdventureWorksAngularApp"));

    var element;
    beforeEach(inject(function ($rootScope, $compile, FakeProductData) {

        // ** Act **
        // Create a Mock Scope
        scope = $rootScope.$new();
        scope.product = FakeProductData;

        // Compile a piece of HTML containing the directive
        element = $compile("<productlink></productlink>")(scope);

        // fire all the watches
        scope.$digest();
    }));

    it("Replaces the element with the appropriate content", function () {
        // ** Assert **
        // Check that the compiled element contains the templated content
        expect(element.html()).toContain('<a href="#/products/3"');
        expect(element.html()).toContain("BB Ball Bearing");
    });
});