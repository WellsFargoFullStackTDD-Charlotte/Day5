﻿describe("Service: AdventureWorksService", function () {

    // ** Arrange **
    beforeEach(module("AdventureWorksAngularApp"));

    var products;
    beforeEach(inject(function ($httpBackend, AdventureWorksService, AdventureWorksServiceURL, FakeProductsData) {
        // Fake Products Data
        $httpBackend.expectGET(AdventureWorksServiceURL.url).respond(FakeProductsData);

        // ** Act **
        AdventureWorksService.getProducts().success(function (response) {
            products = response;
        });

        // Then we flush the httpBackend to resolve the fake http call
        $httpBackend.flush();
    }));

    // ** Assert **
    // Test that controller returns 3 products
    it("should return a list with three products", function () {
        // ** Assert ** 
        expect(products.length).toEqual(3);
    });

    // Check products Name matches fake data
    it("should retrieve the names of the products", function () {
        expect(products[0].Name).toBe("Adjustable Race");
        expect(products[1].Name).toBe("Bearing Ball");
        expect(products[2].Name).toBe("BB Ball Bearing");
    });

});
